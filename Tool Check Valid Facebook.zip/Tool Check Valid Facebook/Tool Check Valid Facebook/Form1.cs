﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Text.RegularExpressions;
using xNet;
using System.Net;

namespace Tool_Check_Valid_Facebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        private void check(string email, string proxy)
        {
            try
            {
                HttpRequest http = new HttpRequest();
                if (proxy != null)
                {
                    http.Proxy = HttpProxyClient.Parse(proxy);
                }
                var data1 = http.Get("https://mbasic.facebook.com/").ToString();
                if (data1 != null)
                {

                    string lsd = Regex.Match(data1, "\"lsd\" value=\"(.*?)\"").Groups[1].ToString();
                    string jazoest = Regex.Match(data1, "\"jazoest\" value=\"(.*?)\"").Groups[1].ToString();
                    string url = "https://mbasic.facebook.com/login/identify/?ctx=recover";
                    string datapost = "lsd=" + lsd + "&jazoest=" + jazoest + "&email=" + email + "&did_submit=Search";
                    string contenttype = "application/x-www-form-urlencoded";
                    var data2 = http.Post(url, datapost, contenttype).ToString();
                    if (data2 != "")
                    {
                        richTextBox1.AppendText(email + "|Fail\n");
                        return;
                    }
                    richTextBox1.AppendText(email + "|Success\n");

                }
            }
            catch
            {

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button1.Text = "Đang chạy";
            new Thread(() =>
            {
                string[] mail = File.ReadAllLines("listmail.txt");
                foreach (string temp in mail)
                {
                    check(temp, "45.140.13.119:9132:lnqexway:d3gnnyj4rdiw");
                }
            }).Start();
            
        }
    }
}
